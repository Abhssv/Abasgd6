const { SlashCommandBuilder,Events,StringSelectMenuBuilder ,Client, ActivityType,ModalBuilder,TextInputStyle, EmbedBuilder , PermissionsBitField,ButtonStyle, TextInputBuilder, ActionRowBuilder,ButtonBuilder,MessageComponentCollector } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/toolsDB.json")
module.exports = (client199) => {
  client199.on(Events.InteractionCreate , async(interaction) =>{
    if (!interaction.isModalSubmit()) return;
  
    if (interaction.customId === 'updatetools') {
    
      const oldName = interaction.fields.getTextInputValue('oldName');
      const newName = interaction.fields.getTextInputValue('newName');
      const newPrice = interaction.fields.getTextInputValue('newPrice');
      const newLink = interaction.fields.getTextInputValue('newLink');
  
      const foundtoolss = await db.get(`toolss_${interaction.guild.id}`, { toolssName: oldName });
  
      let thetoolsName;
      if (Array.isArray(foundtoolss) && foundtoolss.length > 0) {
            
        const selectedtools = foundtoolss.find(tools => tools.toolsName === oldName);
        if (selectedtools) {
          thetoolsName = selectedtools.toolsName;
        } else {
          return interaction.reply({ content: `** قم بإدخال إسم منتج صحيح**`, ephemeral: true });
        }
      }
  
      if(isNaN(newPrice)) return interaction.reply({ content: `**قم إدخال سعر المنتج بطريقة صحيحة.**`, ephemeral:true });
  
      const checkData = await db.get(`toolss_${interaction.guild.id}`);
      const removingtools = checkData.filter(re => re.toolsName !== thetoolsName);
      await db.set(`toolss_${interaction.guild.id}`, removingtools);
  
      await db.push(`toolss_${interaction.guild.id}`, {
        toolsName: newName,
        toolsPrice: newPrice,
        toolsLink: newLink
      });
  
      interaction.reply({ content: `** تم تعديل المنتج بنجاح**` });
  
    }
  })};