
  const { Client,Discord, Collection, AuditLogEvent,discord,GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, Embed } = require("discord.js");
const { Database } = require("st.db")
const ticketbilDB = new Database("/Json-db/Bots/ticketbilDB.json")
const tokens = new Database("/tokens/tokens")
const tier1subscriptions = new Database("/database/makers/tier1/subscriptions")


  let ticketbil = tokens.get('ticketbil')
if(!ticketbil) return;
const path = require('path');
const { readdirSync } = require("fs");
let theowner;
ticketbil.forEach(async(data) => {
  const { REST } = require('@discordjs/rest');
  const { Routes } = require('discord-api-types/v10');
  const { prefix , token , clientId , owner } = data;
  theowner = owner
  const client00 = new Client({intents: 32767, shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,]});
  client00.commands = new Collection();
  require(`./handlers/events`)(client00);
  require(`./handlers/ticketbilClaim`)(client00);
  require(`./handlers/ticketbilCreate`)(client00);
  require(`./handlers/ticketbilDelete`)(client00);
  require(`./handlers/ticketbilSubmitCreate`)(client00);
  require(`./handlers/ticketbilUnclaim`)(client00);
  client00.events = new Collection();
  require(`../../events/requireBots/ticketbil-commands`)(client00);
  const rest = new REST({ version: '10' }).setToken(token);
  client00.on("ready" , async() => {

      try {
        await rest.put(
          Routes.applicationCommands(client00.user.id),
          { body: ticketbilSlashCommands },
          );
          
        } catch (error) {
          console.error(error)
        }

    });
    require(`./handlers/events`)(client00)

  const folderPath = path.join(__dirname, 'slashcommand00');
  client00.ticketbilSlashCommands = new Collection();
  const ticketbilSlashCommands = [];
  const ascii = require("ascii-table");
  const table = new ascii("ticketbil commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
    )) {
      for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
      )) {
        let command = require(`${folderPath}/${folder}/${file}`);
        if (command) {
          ticketbilSlashCommands.push(command.data.toJSON());
          client00.ticketbilSlashCommands.set(command.data.name, command);
          if (command.data.name) {
            table.addRow(`/${command.data.name}`, "🟢 Working");
          } else {
            table.addRow(`/${command.data.name}`, "🔴 Not Working");
          }
        }
  }
}



const folderPath2 = path.join(__dirname, 'commands00');

for(let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
  for(let fiee of(readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
    const commander = require(`${folderPath2}/${foldeer}/${fiee}`)
  }
}

require(`../../events/requireBots/ticketbil-commands`)(client00)
require("./handlers/events")(client00)

	for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
		const event = require(`./events/${file}`);
	if (event.once) {
		client00.once(event.name, (...args) => event.execute(...args));
	} else {
		client00.on(event.name, (...args) => event.execute(...args));
	}
	}

client00.on('ready' , async() => {
  setInterval(async() => {
    let ticketbilTokenss = tokens.get(`ticketbil`)
    let thiss = ticketbilTokenss.find(br => br.token == token)
    if(thiss) {
      if(thiss.timeleft <= 0) {
        await client00.destroy();
        console.log(`${clientId} Ended`)
      }
    }
  }, 1000);
})


  client00.on("interactionCreate" , async(interaction) => {
    if (interaction.isChatInputCommand()) {
      
	    if(interaction.user.bot) return;

      
      const command = client00.ticketbilSlashCommands.get(interaction.commandName);
	    
      if (!command) {
        console.error(`No command matching ${interaction.commandName} was found.`);
        return;
      }
      if (command.ownersOnly === true) {
        if (owner != interaction.user.id) {
          return interaction.reply({content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true});
        }
      }
      try {

        await command.execute(interaction);
      } catch (error) {
			console.error(`Error executing ${interaction.commandName}`);
			console.error(error);
		}
    }
  } )

  client00.on("messageCreate" , async(message) => {
    let client = message.client;
  if (message.author.bot) return;
  if (message.channel.type === 'dm') return;


  if(!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/g); 
  const cmd = args.shift().toLowerCase();
  if(cmd.length == 0 ) return;
  let command = client.commands.get(cmd)
  if(!command) command = client00.commands.get(client.commandaliases.get(cmd));

  if(command) {
    if(command.ownersOnly) {
			if (owner != message.author.id) {
			  return message.reply({content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true});
			}
    }
    if(command.cooldown) {
        
      if(cooldown.has(`${command.name}${message.author.id}`)) return message.reply({ embeds:[{description:`**عليك الانتظار\`${ms(cooldown.get(`${command.name}${message.author.id}`) - Date.now(), {long : true}).replace("minutes", `دقيقة`).replace("seconds", `ثانية`).replace("second", `ثانية`).replace("ms", `ملي ثانية`)}\` لكي تتمكن من استخدام الامر مجددا.**`}]}).then(msg => setTimeout(() => msg.delete(), cooldown.get(`${command.name}${message.author.id}`) - Date.now()))
      command.run(client, message, args)
      cooldown.set(`${command.name}${message.author.id}`, Date.now() + command.cooldown)
      setTimeout(() => {
        cooldown.delete(`${command.name}${message.author.id}`)
      }, command.cooldown);
  } else {
    command.run(client, message, args)
  }}});





   client00.login(token)
   .catch(async(err) => {
    const filtered = ticketbil.filter(bo => bo != data)
			await tokens.set(`ticketbil` , filtered)
      console.log(`${clientId} Not working and removed `)
   });


})
