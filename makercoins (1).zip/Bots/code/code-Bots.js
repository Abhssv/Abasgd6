
  const { Client, Collection, discord,GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, Attachment } = require("discord.js");
  const { Database } = require("st.db")
  const codeDB = new Database("/Json-db/Bots/codeDB.json")
  const tokens = new Database("/tokens/tokens")
  const tier1subscriptions = new Database("/database/makers/tier1/subscriptions")
  
  let code = tokens.get('code')
  if(!code) return;
  
  const path = require('path');
  const { readdirSync } = require("fs");
  let theowner;
  code.forEach(async(data) => {
    const { REST } = require('@discordjs/rest');
    const { Routes } = require('discord-api-types/v9');
    const { prefix , token , clientId , owner } = data;
    theowner = owner
    const client99 = new Client({intents: [GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent], shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,]});
    client99.commands = new Collection();
    require(`./handlers/events`)(client99);
    require(`./handlers/edit-code`)(client99);
    client99.events = new Collection();
    require(`../../events/requireBots/code-commands`)(client99);
    const rest = new REST({ version: '9' }).setToken(token);
    client99.on("ready" , async() => {
  
        try {
          await rest.put(
            Routes.applicationCommands(client99.user.id),
            { body: codeSlashCommands },
            );
            
          } catch (error) {
            console.error(error)
          }
  
      });
      require(`./handlers/events`)(client99)
  
    const folderPath = path.join(__dirname, 'slashcommand99');
    client99.codeSlashCommands = new Collection();
    const codeSlashCommands = [];
    const ascii = require("ascii-table");
    const table = new ascii("code commands").setJustify();
    for (let folder of readdirSync(folderPath).filter(
      (folder) => !folder.includes(".")
      )) {
        for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
        f.endsWith(".js")
        )) {
          let command = require(`${folderPath}/${folder}/${file}`);
          if (command) {
            codeSlashCommands.push(command.data.toJSON());
            client99.codeSlashCommands.set(command.data.name, command);
            if (command.data.name) {
              table.addRow(`/${command.data.name}`, "🟢 Working");
            } else {
              table.addRow(`/${command.data.name}`, "🔴 Not Working");
            }
          }
    }
  }
  
  
  
  const folderPath2 = path.join(__dirname, 'commands99');
  
  for(let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
    for(let fiee of(readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
      const commander = require(`${folderPath2}/${foldeer}/${fiee}`)
    }
  }
  
  require(`../../events/requireBots/code-commands`)(client99)
  require("./handlers/events")(client99)
  
      for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
          const event = require(`./events/${file}`);
      if (event.once) {
          client99.once(event.name, (...args) => event.execute(...args));
      } else {
          client99.on(event.name, (...args) => event.execute(...args));
      }
      }
      client99.on('ready' , async() => {
        setInterval(async() => {
          let BroadcastTokenss = tokens.get(`code`)
          let thiss = BroadcastTokenss.find(br => br.token == token)
          if(thiss) {
            if(thiss.timeleft <= 0) {
              await client99.destroy();
              console.log(`${clientId} Ended`)
            }
          }
        }, 1000);
      })
 client99.on("interactionCreate" , async(interaction) => {
    if (interaction.isChatInputCommand()) {
      
	    if(interaction.user.bot) return;

      
      const command = client99.codeSlashCommands.get(interaction.commandName);
	    
      if (!command) {
        return;
      }
      if (command.ownersOnly === true) {
        if (owner != interaction.user.id) {
          return interaction.reply({content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true});
        }
      }
      try {

        await command.execute(interaction);
      } catch (error) {
			return
		}
    }
  } )
client99.login(token)
    })
    