const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/codeDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('remove-mumber-blacklist')
    .setDescription('ازالة شخص من قائمة الحظر')
  .addUserOption(Option => Option
    .setName(`user`)
    .setDescription(`اسم الشخص`)
    .setRequired(true)),
  
  async execute(interaction) {
    const userToRemove = interaction.options.getUser('user')
    const bannedUsers = await db.get(`BannedUsers_${interaction.guild.id}`) || [];
    const index = bannedUsers.indexOf(userToRemove.id);
    if (index !== -1) {
      bannedUsers.splice(index, 1);
      await db.set(`BannedUsers_${interaction.guild.id}`, bannedUsers);
      interaction.reply({ content: `**تمت إزالة <@${userToRemove.id}>من قائمة المحظورين.**`, ephemeral: true });
    } else {
      interaction.reply({ content: `**<@${userToRemove.id}> لم يتم إضافته إلى قائمة المحظورين من قبل.**`, ephemeral: true });
    }
  }
};